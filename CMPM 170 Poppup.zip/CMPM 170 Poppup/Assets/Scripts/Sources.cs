using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sources : MonoBehaviour
{
    /* 
     You Win: https://freesound.org/people/bolkmar/sounds/442324/
     Money: https://freesound.org/people/Pavee2/sounds/584123/
     Notification: https://freesound.org/people/suyashjemar/sounds/618608/
     message: https://freesound.org/people/AnthonyRox/sounds/740422/
     
     */
}
